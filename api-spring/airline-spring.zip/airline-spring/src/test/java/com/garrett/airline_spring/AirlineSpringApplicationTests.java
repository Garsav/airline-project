package com.garrett.airline_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
